// api url
//const API_URL = "https://confirmed-brief-roadway.glitch.me/fetchinfo"


// intent("My Play $(songName*)",(p) => {
//     p.play("Music Is Now Playing");
//     
//     var thisSongName = p.songName.value;
//     
//     p.play({command: 'playSong', thisSongName});
// });
// 
intent("play $(source* (.*))",(p) => {
    let songName;
    if(p.source.value){
        songName = p.source.value;
    } else {
        songName = "else"
    }
    
    
    p.play({command: 'play', songName});
});


intent("song number $(source* (.*))",(p) => {
    let songNumber;
    if(p.source.value){
        songNumber = p.source.value;
    } else {
        songNumber = "else"
    }
    
    p.play("done")
    p.play({command: 'startSong', songNumber});
});


intent("stop",(p) => {
    
    p.play({command: 'stop'});
});

intent("change",(p) => {
    
    p.play({command: 'change'});
});











// 
// 
// 
// intent("open project $(sourceNo* (.*))",(p) => {
//     
//     let no;
//      if(p.sourceNo.value){
//         no = p.sourceNo.value;
//     } else {
//         no = "else is called"
//     }
//     
//     p.play("Opening A Project " + no);
//     p.play({command: 'open',no});
// });
// 
// intent("source code for project $(sourceNo* (.*))",(p) => {
//     
//     let no;
//      if(p.sourceNo.value){
//         no = p.sourceNo.value;
//     } else {
//         no = "else is called"
//     }
//     
//     p.play("Opening A Project Source Code " + no);
//     p.play({command: 'view',no});
// });