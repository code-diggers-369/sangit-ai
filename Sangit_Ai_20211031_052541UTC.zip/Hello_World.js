
intent("play $(source* (.*))",(p) => {
    let songName;
    if(p.source.value){
        songName = p.source.value;
    } else {
        songName = "else"
    }
    
    
    p.play({command: 'play', songName});
});


intent("song number $(source* (.*))",(p) => {
    let songNumber;
    if(p.source.value){
        songNumber = p.source.value;
    } else {
        songNumber = "else"
    }
    
    p.play("done")
    p.play({command: 'startSong', songNumber});
});


intent("stop",(p) => {
    
    p.play({command: 'stop'});
});

intent("change",(p) => {
    
    p.play({command: 'change'});
});







